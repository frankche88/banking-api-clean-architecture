INSERT INTO users(username,password,customer_id, enabled)
VALUES ('admin','$2a$10$04TVADrR6/SPLBjsK0N30.Jf5fNjBugSACeGv1S69dZALR7lSov0y', 0, true);
INSERT INTO users(username,password,enabled)
VALUES ('client1','$2a$10$04TVADrR6/SPLBjsK0N30.Jf5fNjBugSACeGv1S69dZALR7lSov0y', 2, true);