INSERT INTO bank_account(number, balance, locked, customer_id) VALUES('123-456-001', 1500, 0, 2);
INSERT INTO bank_account(number, balance, locked, customer_id) VALUES('123-456-002', 1800, 0, 2);