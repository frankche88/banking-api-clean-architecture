package pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.resources;

import io.dropwizard.hibernate.UnitOfWork;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.Aviso;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.db.AvisoDAO;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/aviso")
@Produces(MediaType.APPLICATION_JSON)
public class ListAvisoResource {

    private final AvisoDAO avisoDAO;

    public ListAvisoResource(AvisoDAO peopleDAO) {
        this.avisoDAO = peopleDAO;
    }

    @POST
    @UnitOfWork
    public Aviso createAviso(Aviso aviso) {
        return avisoDAO.create(aviso);
    }

    @GET
    @UnitOfWork
    public List<Aviso> listAviso() {
        return avisoDAO.findAll();
    }

}
