package pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.fileupload.resources;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import rx.Observable;
import rx.Scheduler;
import rx.schedulers.Schedulers;

public class ParallelTest {

	private static final Random rand = new Random();
	
	static int threadCt = Runtime.getRuntime().availableProcessors() + 1;

	static ExecutorService executor = Executors.newFixedThreadPool(threadCt);
	static Scheduler scheduler = Schedulers.from(executor);

	

	public static void main(String[] args) {

		AtomicInteger key = new AtomicInteger();
				
		
		Observable<Integer> vals = Observable.range(1, 1000);
		
		
		
//		vals.groupBy(v -> key.getAndIncrement() % 5)
//			.flatMap(g -> g.observeOn(Schedulers.io(), 10)
//					.map(i -> intenseCalculation(i)))
//			.toList()
//			.subscribe(val -> System.out
//				.println("Subscriber received " + val + " on " + Thread.currentThread().getName()));
		
		
		Observable.range(1,100)
		.flatMap(i -> Observable.just(i)
		    .subscribeOn(scheduler)
		    .map(i2 -> intenseCalculation(i2))
		    .doAfterTerminate(() -> executor.shutdown())
		)
	    .toList().subscribe(System.out::println);
		

//		vals.flatMap(val -> Observable.just(val)
//				.subscribeOn(Schedulers.computation())
//				.map(i -> intenseCalculation(i)))
//		.toList()
//				.subscribe(val -> System.out
//						.println("Subscriber received " + val + " on " + Thread.currentThread().getName()));

		waitSleep();
	}

	public static void waitSleep() {
		try {
			Thread.sleep(90000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static int intenseCalculation(int i) {
		try {
			System.out.println("Calculating " + i + " on " + Thread.currentThread().getName());
			Thread.sleep(randInt(1000, 5000));
			return i;
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
	}

	public static int randInt(int min, int max) {
		return rand.nextInt((max - min) + 1) + min;
	}

}
