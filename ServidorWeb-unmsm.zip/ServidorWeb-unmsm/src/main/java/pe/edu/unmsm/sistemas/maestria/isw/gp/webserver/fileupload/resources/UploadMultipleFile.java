package pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.fileupload.resources;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;

import com.codahale.metrics.annotation.Timed;

import io.dropwizard.hibernate.UnitOfWork;

public class UploadMultipleFile {
	
	@Path("/uploadPhoto")
	@POST
	@Timed
	@UnitOfWork
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	public Response uploadFile(FormDataMultiPart multiPart) {


	    List<AdImage> images = new ArrayList<AdImage>();
	    List<FormDataBodyPart> bodyParts =
	            multiPart.getFields("file");
	    for (FormDataBodyPart part : bodyParts) {
	        images.add(writeImageAndSave(part.getValueAs(InputStream.class
	        ), part.getFormDataContentDisposition()));
	    }

	    return Response.ok(toJson(images), MediaType.APPLICATION_JSON).build();
	}
	
	private AdImage writeImageAndSave(InputStream valueAs, FormDataContentDisposition formDataContentDisposition) {
		// TODO Auto-generated method stub
		return new AdImage();
	}

	private String toJson(List<AdImage> images) {
		// TODO Auto-generated method stub
		return "{}";
	}

	public class AdImage {
		
	}
	

}
