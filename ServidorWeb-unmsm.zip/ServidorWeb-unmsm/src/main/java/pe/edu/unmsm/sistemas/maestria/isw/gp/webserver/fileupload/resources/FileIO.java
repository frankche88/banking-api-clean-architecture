package pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.fileupload.resources;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Optional;
import com.google.common.hash.HashCode;
import com.google.common.hash.HashFunction;
import com.google.common.hash.Hashing;

import io.dropwizard.hibernate.UnitOfWork;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.Aviso;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.db.AvisoDAO;

/**
 */
@Path("/file")
public class FileIO {

	private final AvisoDAO avisoDAO;

	public FileIO(AvisoDAO avisoDAO) {
		this.avisoDAO = avisoDAO;
	}

	private final Logger LOGGER = LoggerFactory.getLogger(FileIO.class);

	@GET
	@Path("/all")
	@UnitOfWork
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllFilesUploaded() {
		
		List<Aviso> avisos = avisoDAO.findAll();
	
			return Response.ok(avisos).build();
	}

	@POST
	@Path("/processUpload")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	@UnitOfWork
	public Response uploadFile(@FormDataParam("issueDate") String fechaAviso, @FormDataParam("qqfile") InputStream uploadedInputStream,
			@FormDataParam("qqfile") FormDataContentDisposition fileDetail) throws IOException, ParseException {
		LOGGER.info("Size of file:" + fileDetail.getSize());

		Aviso aviso = new Aviso();
		
		
		byte[] buffer = new byte[8000];

        int bytesRead = 0;

        ByteArrayOutputStream bao = new ByteArrayOutputStream();

        while((bytesRead = uploadedInputStream.read(buffer)) != -1) {
           bao.write(buffer, 0, bytesRead);
        }

        //byte[] data = bao.toByteArray();
        

		String directoryName = "./avisos";
		// obtener el direcciotrio de la base de datos
		File directory = new File(String.valueOf(directoryName));
		
		
		//Document doc = Jsoup.parse(new String(buffer));
		
		//LOGGER.info("HTML:" + doc.html());
		

		if (!directory.exists()) {

			directory.mkdir();
		}
		
		HashFunction hf = Hashing.sha256();
		
		HashCode hash = hf.hashBytes(bao.toByteArray());
		
		aviso.setFilename(fileDetail.getFileName());

		aviso.setFilepath(directoryName);
		
		aviso.setHashfile(hash.toString());
		
		DateFormat df = new SimpleDateFormat("DD/MM/YYYY");
		//fechaAviso
		
		
		aviso.setFechaAviso(df.parse(fechaAviso));
		
		
		Long isHash = avisoDAO.findByHash(hash.toString());
		
		if(isHash > 0) {
			
			Map<String, Object> ret = new HashMap<>();
			
			ret.put("success", false);
			ret.put("message", "msg_rejected");

			return Response.ok(ret, MediaType.APPLICATION_JSON_TYPE).build();
			
		}

		avisoDAO.create(aviso);

		// guardar en disco
		
		File targetFile = new File(directoryName + "/" + aviso.getId() + "_" + aviso.getFilename());

		
		OutputStream outStream = new FileOutputStream(targetFile);
		
		outStream.write(buffer);
		
		outStream.close();
		
		
		
		Map<String, Object> ret = new HashMap<>();
		
		ret.put("success", true);
		ret.put("message", "msg_accepted");

		return Response.ok(ret, MediaType.APPLICATION_JSON_TYPE).build();
	}
	
	

	@GET
	@Path("/showhtml/{id}")
	@Produces(MediaType.TEXT_HTML)
	@UnitOfWork
	public Response showhtml(@PathParam("id") Long id) throws IOException {
		
		LOGGER.info("HTML id:" + id);
		
		Optional<Aviso> aviso = avisoDAO.findById(id);
		
		if(!aviso.isPresent()) {
			
			return Response.status(Response.Status.NOT_FOUND).entity("Entity not found for UUID: ").build();
		}
		
		
		
		File file = new File(aviso.get().fullpath());
		
		
		
		if(!file.exists()) {
		
			return Response.status(Response.Status.NOT_FOUND).entity("Entity not found for UUID: ").build();
		}
		byte[] encoded = Files.readAllBytes(Paths.get(aviso.get().fullpath()));
		

		return Response.ok(new String(encoded, StandardCharsets.UTF_8), MediaType.TEXT_HTML).build();

	}

}
