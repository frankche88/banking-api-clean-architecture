package pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "aviso",
indexes = @Index(columnList = "hashfile", unique = true))
@NamedQueries({
    @NamedQuery(
        name = "pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.Aviso.findAll",
        query = "SELECT a FROM Aviso a"
    ),
    @NamedQuery(
        name = "pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.findById",
        query = "SELECT a FROM Aviso a WHERE a.id = :id"
    ),
    @NamedQuery(
            name = "pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.countId",
            query = "SELECT count(a.id) FROM Aviso a"
        ),
    @NamedQuery(
            name = "pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.findByHash",
            query = "SELECT count(a.id) FROM Aviso a WHERE a.hashfile = :hashfile"
        )
})
public class Aviso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "filename", nullable = false)
    private String filename;

    @Column(name = "filepath", nullable = false)
    private String filepath;

    @Column(name = "hashfile", nullable = false)
    private String hashfile;
    
    @Column(name = "fechaAviso", nullable = false)
    private Date fechaAviso;
    
    public boolean isVencido() {
    	
    	LocalDate now = LocalDate.now();
    	
    	if(fechaAviso == null) {
    		return true;
    	}
    	
    	LocalDate date = fechaAviso.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    	
    	System.out.println("Aviso.isVencido() fecha BD" + date);
    	
    	System.out.println("Aviso.isVencido() fecha no" + date);
    	
    	return date.compareTo(now) < 0 ? true: false; 
    }

	public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    public String getHashfile() {
		return hashfile;
	}

	public void setHashfile(String hashfile) {
		this.hashfile = hashfile;
	}
    
    public String fullpath() {
    	return filepath + "/" + id + "_" + filename;
    }

	public Date getFechaAviso() {
		return fechaAviso;
	}

	public void setFechaAviso(Date fechaAviso) {
		this.fechaAviso = fechaAviso;
	}
}
