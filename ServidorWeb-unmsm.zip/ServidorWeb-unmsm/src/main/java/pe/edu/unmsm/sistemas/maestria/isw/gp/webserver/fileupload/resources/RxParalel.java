package pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.fileupload.resources;

import java.util.Random;

import rx.Observable;
import rx.schedulers.Schedulers;

public class RxParalel {

	public static void main(String args[]) {

		simpleObservable();

		// mainThreadObservable();

		// changeThreadObservable();

		parallelThreadObservable();

		parallelToListThreadObservable();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static void simpleObservable() {
		Observable<Integer> vals = Observable.range(1, 10);

		vals.subscribe(val -> System.out.println(val));
	}

	private static void mainThreadObservable() {
		
		System.out.println("RxParalel.mainThreadObservable()");
		
		Observable<Integer> vals = Observable.range(1, 10);
		
		vals.map(i -> intenseCalculation(i))
			.subscribe(val -> System.out.println(val));
	}

	private static void changeThreadObservable() {
		
		System.out.println("RxParalel.changeThreadObservable()");
		
		Observable<Integer> vals = Observable.range(1, 10);

		vals.subscribeOn(Schedulers.computation())
		.map(i -> intenseCalculation(i))
		.subscribe(
				val -> System.out.println("Subscriber received " + val + " on " + Thread.currentThread().getName()));
	}

	private static void parallelThreadObservable() {

		System.out.println("RxParalel.parallelThreadObservable()");
		Observable<Integer> vals = Observable.range(1, 10);

		vals.flatMap(val -> Observable.just(val)
				.subscribeOn(Schedulers.computation())
				.map(i -> intenseCalculation(i)))
				.subscribe(val -> System.out
						.println("Subscriber received " + val + " on " + Thread.currentThread().getName()));
	}

	private static void parallelToListThreadObservable() {

		System.out.println("RxParalel.parallelToListThreadObservable()");

		Observable<Integer> vals = Observable.range(1, 10);

		vals.flatMap(val -> Observable.just(val)
				.subscribeOn(Schedulers.computation())
				.map(i -> intenseCalculation(i)))
				.toList().subscribe(val -> System.out
						.println("Subscriber received " + val + " on " + Thread.currentThread().getName()));
	}

	private static Object intenseCalculation(Integer i) {
		try {

			Thread.sleep(randInt(100, 500));

			System.out.println("Calculating " + i + " on " + Thread.currentThread().getName());
			return i;
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
	}

	private static long randInt(int aStart, int aEnd) {

		Random randomGenerator = new Random();

		if (aStart > aEnd) {
			throw new IllegalArgumentException("Start cannot exceed End.");
		}
		// get the range, casting to long to avoid overflow problems
		long range = (long) aEnd - (long) aStart + 1;
		// compute a fraction of the range, 0 <= frac < range
		long fraction = (long) (range * randomGenerator.nextDouble());
		int randomNumber = (int) (fraction + aStart);

		return randomNumber;
	}

}
