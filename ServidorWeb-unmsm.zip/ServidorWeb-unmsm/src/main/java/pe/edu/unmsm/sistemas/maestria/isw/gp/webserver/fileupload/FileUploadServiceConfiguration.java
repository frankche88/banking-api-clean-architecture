package pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.fileupload;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.dropwizard.Configuration;
import io.dropwizard.db.DataSourceFactory;

/**
 * Created by mihir on 3/1/16.
 */
public class FileUploadServiceConfiguration extends Configuration {
    @NotEmpty
    private String maxFileSizeInMB;
    
    @Valid
    @NotNull
    private DataSourceFactory database = new DataSourceFactory();

    public String getMaxFileSizeInMB() {
        return maxFileSizeInMB;
    }

    public void setMaxFileSizeInMB(String maxFileSizeInMB) {
        this.maxFileSizeInMB = maxFileSizeInMB;
    }
    
    @JsonProperty("database")
    public DataSourceFactory getDataSourceFactory() {
        return database;
    }

    @JsonProperty("database")
    public void setDataSourceFactory(DataSourceFactory dataSourceFactory) {
        this.database = dataSourceFactory;
    }
    

}
