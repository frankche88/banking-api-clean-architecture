package pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.db;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.StringType;

import com.google.common.base.Optional;

import io.dropwizard.hibernate.AbstractDAO;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.Aviso;

public class AvisoDAO extends AbstractDAO<Aviso> {
    public AvisoDAO(SessionFactory factory) {
        super(factory);
    }

    public Optional<Aviso> findById(Long id) {
        return Optional.fromNullable(get(id));
    }
    
    public Long findByHash(String hashfile) {
    	return (Long) namedQuery("pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.findByHash")
    			.setParameter( "hashfile", hashfile, StringType.INSTANCE ).getSingleResult();
    }

    public Aviso create(Aviso aviso) {
        return persist(aviso);
    }

    @SuppressWarnings("unchecked")
	public List<Aviso> findAll() {
        return list(namedQuery("pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.Aviso.findAll"));
    }
    
	public Long countById() {
        return (Long) namedQuery("pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.countId").getSingleResult();
    }
    
    // asc and desc
    @SuppressWarnings("deprecation")
	public List<Aviso> findByFilter(String filter, String sortOrder, int pageNumber, int pageSize) {
    	
    	//Averiguamos que columna es la que se ordena y asignamos la expresion de orden
    	
    	
        Criteria criteria = currentSession().createCriteria(Aviso.class); 
        
        if(StringUtils.isNoneEmpty(filter)) {
        	criteria.add(Restrictions.ilike("filename", filter, MatchMode.ANYWHERE));        	
        }
        
        
        Order order = null;
        if (sortOrder.equals("desc")) {
            order = Order.asc("id");
        } else {
            order = Order.desc("id");
        }
        
        criteria.addOrder(order); 
        
        criteria.setFirstResult(pageNumber * pageSize);
    	criteria.setMaxResults(pageSize);
        
        
        return list(criteria); 
    	
    	
    }
}
