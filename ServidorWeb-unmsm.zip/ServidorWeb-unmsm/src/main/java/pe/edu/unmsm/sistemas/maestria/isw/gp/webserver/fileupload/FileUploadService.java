package pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.fileupload;

import org.glassfish.jersey.media.multipart.MultiPartFeature;

import io.dropwizard.Application;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.hibernate.HibernateBundle;
import io.dropwizard.migrations.MigrationsBundle;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.Aviso;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.db.AvisoDAO;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.fileupload.resources.FileIO;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.fileupload.resources.TableList;
import ru.vyarus.guicey.spa.SpaBundle;


public class FileUploadService extends Application<FileUploadServiceConfiguration> {

	public static void main(String[] args) throws Exception {
		new FileUploadService().run(args);
	}

	private final HibernateBundle<FileUploadServiceConfiguration> hibernateBundle = new HibernateBundle<FileUploadServiceConfiguration>(
			Aviso.class) {
		@Override
		public DataSourceFactory getDataSourceFactory(FileUploadServiceConfiguration configuration) {
			return configuration.getDataSourceFactory();
		}
	};

	@Override
	public void initialize(Bootstrap<FileUploadServiceConfiguration> bootstrap) {
		
		bootstrap.addBundle( new CorsBundle());
		
		bootstrap.addBundle(SpaBundle.app("assets", "/static/", "/")
				.build());
		
		//bootstrap.addBundle(SpaBundle.app("assets", "/assets/", "/")
			//	.preventRedirectRegex("\\.\\w{2,5}(\\?.*)?$").build());
		
		bootstrap.addBundle(new MigrationsBundle<FileUploadServiceConfiguration>() {
            @Override
            public DataSourceFactory getDataSourceFactory(FileUploadServiceConfiguration configuration) {
                return configuration.getDataSourceFactory();
            }
        });
		
		bootstrap.addBundle(hibernateBundle);

	}

	@Override
	public void run(FileUploadServiceConfiguration configuration, Environment environment) throws Exception {

		final AvisoDAO dao = new AvisoDAO(hibernateBundle.getSessionFactory());

		final FileIO resource = new FileIO(dao);
		final TableList tableList = new TableList(dao);
		environment.jersey().register(resource);
		environment.jersey().register(tableList);
		environment.jersey().register(MultiPartFeature.class);
	}

}
