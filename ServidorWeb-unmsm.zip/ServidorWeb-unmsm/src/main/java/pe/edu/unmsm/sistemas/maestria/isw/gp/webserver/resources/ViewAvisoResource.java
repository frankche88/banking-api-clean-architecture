package pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.resources;

import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.google.common.base.Optional;

import io.dropwizard.hibernate.UnitOfWork;
import io.dropwizard.jersey.params.LongParam;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.Aviso;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.db.AvisoDAO;

@Path("/aviso/{avisoId}")
@Produces(MediaType.APPLICATION_JSON)
public class ViewAvisoResource {

    private final AvisoDAO avisoDAO;

    public ViewAvisoResource(AvisoDAO peopleDAO) {
        this.avisoDAO = peopleDAO;
    }

    @GET
    @UnitOfWork
    public Aviso getPerson(@PathParam("avisoId") LongParam avisoId) {
        final Optional<Aviso> aviso = avisoDAO.findById(avisoId.get());
        if (!aviso.isPresent()) {
            throw new NotFoundException("No such aviso.");
        }
        return aviso.get();
    }

}
