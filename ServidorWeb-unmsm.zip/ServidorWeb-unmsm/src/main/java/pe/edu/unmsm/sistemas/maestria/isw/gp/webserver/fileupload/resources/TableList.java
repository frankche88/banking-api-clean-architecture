package pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.fileupload.resources;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.dropwizard.hibernate.UnitOfWork;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.core.Aviso;
import pe.edu.unmsm.sistemas.maestria.isw.gp.webserver.db.AvisoDAO;

/**
 */
@Path("/table")
public class TableList {

	private final AvisoDAO avisoDAO;

	public TableList(AvisoDAO avisoDAO) {
		this.avisoDAO = avisoDAO;
	}

	private final Logger LOGGER = LoggerFactory.getLogger(TableList.class);

	@GET
	@Path("/all")
	@UnitOfWork
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllFilesUploaded() {

		List<Aviso> avisos = avisoDAO.findAll();

		return Response.ok(avisos).build();
	}

	@GET
	@Path("/courses")
	@UnitOfWork
	@Produces(MediaType.APPLICATION_JSON)
	public Response filterFilesUploaded(
			@QueryParam("filter")String filter, 
			@QueryParam("sortOrder")String sortOrder, 
			@QueryParam("pageNumber")int pageNumber, 
			@QueryParam("pageSize")int pageSize) {
		
		LOGGER.info("filter:" + filter);
		List<Aviso> avisos = avisoDAO.findByFilter(filter, sortOrder, pageNumber, pageSize);
		
		//System.out.println("TableList.filterFilesUploaded()" +  avisos.get(0).getHashfile());

		return Response.ok(avisos).build();
	}
	


	@GET
	@Path("/count")
	@UnitOfWork
	@Produces(MediaType.APPLICATION_JSON)
	public Response getRowNumber() {

		Long count = avisoDAO.countById();

		return Response.ok(count).build();
	}

}
