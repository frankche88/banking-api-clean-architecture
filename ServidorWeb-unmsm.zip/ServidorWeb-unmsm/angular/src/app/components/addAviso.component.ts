import { Component } from '@angular/core';

@Component({
  selector: 'authenticity-verification',
  templateUrl: '../views/AddAviso.html'
})
export class AddAvisoComponent {

    constructor() {
        

    }

    ngOnInit() {
    }
}