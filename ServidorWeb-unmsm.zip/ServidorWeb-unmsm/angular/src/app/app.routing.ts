import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// componentes
import { AvisoQueryComponent } from './components/avisoQuery.component';
import { AddAvisoComponent } from './components/addAviso.component';
import { ShowHtmlComponent } from './show-html/show-html.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const APPROUTES: Routes = [
    {
        path: '',
        component: AvisoQueryComponent
    },
    {
        path: 'avisos',
        component: AvisoQueryComponent
    },
    {
        path: 'nuevo-aviso',
        component: AddAvisoComponent
    },
    {
        path: 'notfound',
        component: PageNotFoundComponent
    },
    {
        path: 'show-aviso/:id',
        component: ShowHtmlComponent
    },
    {
        path: '**',
        component: AvisoQueryComponent
    }
];

export const APPROUTINGPROVIDERS: any[] = [];
export const ROUTING: ModuleWithProviders = RouterModule.forRoot(APPROUTES); // Modulo
