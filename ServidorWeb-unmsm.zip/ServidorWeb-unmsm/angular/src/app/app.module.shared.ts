import {NgModule} from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';




import { MatInputModule, MatTableModule, MatPaginatorModule, MatIconModule, MatSortModule, MatProgressSpinnerModule } from '@angular/material';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';

// Routes
import {ROUTING, APPROUTINGPROVIDERS} from './app.routing';

// Components
import {AppComponent} from './app.component';
import {AvisoQueryComponent} from './components/avisoQuery.component';

import {AvisoTableArticleComponent} from './components/avisoTableArticle.component';
import {AddAvisoComponent} from './components/addAviso.component';

import {UploadAvisoArticleComponent} from './components/uploadAvisoArticle.component';

import { ShowHtmlComponent } from './show-html/show-html.component';

import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

import { AvisoService } from './services/aviso.service';


import { KeepHtmlPipe } from './pipes/keep-html.pipe';

// Custom Validators
import {ShowErrorsComponent} from './components/showErrorsComponent';


@NgModule({
  declarations: [
    AppComponent,
    AvisoQueryComponent,
    AvisoTableArticleComponent,
    AddAvisoComponent,
    UploadAvisoArticleComponent,
    ShowErrorsComponent,
    ShowHtmlComponent,
    PageNotFoundComponent,
    KeepHtmlPipe
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    HttpModule,
    FormsModule,
    MatInputModule, 
    MatTableModule, 
    MatPaginatorModule,
    MatProgressSpinnerModule, 
    MatSortModule,
    MatIconModule,
    HttpClientModule,
    ROUTING
  ],
  providers: [
    APPROUTINGPROVIDERS,
    AvisoService
  ]
})
export class AppModuleShared {
}

