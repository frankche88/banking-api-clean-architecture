import { Injectable } from '@angular/core';
import { HttpClient, HttpParams }   from '@angular/common/http';
import { Observable }   from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { Aviso } from '../models/aviso.model';
import { EndPoints } from './config';

@Injectable()
export class AvisoService {


  private serviceUrl = EndPoints.listAviso;
  
  constructor(private http: HttpClient) { }
        
  getAviso(): Observable<Aviso[]> {
      return this.http.get<Aviso[]>(this.serviceUrl);
  
  }
  
  findAvisos(filter = '', sortOrder = 'asc',
        pageNumber = 0, pageSize = 3): Observable<Aviso[]> {
      return this.http.get<Aviso[]>(this.serviceUrl, {
            params: new HttpParams()
                .set('filter', filter)
                .set('sortOrder', sortOrder)
                .set('pageNumber', pageNumber.toString())
                .set('pageSize', pageSize.toString())
        });
  
  }
  
  countAvisos(): Observable<number> {
        return this.http.get<number>(EndPoints.countAviso);
  }
    
  findAviso(id: number) {
      
      return this.http.get(EndPoints.showHtmlAviso + '/' + id, {responseType: 'text'});
  }
  

}
