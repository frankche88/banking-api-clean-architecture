export const Config = {
    SiteKey: '6LfHTFYUAAAAAMj8lHPOFkwLC-HIL-K4MTEVuKzP',
    upload: '/api/file/processUpload'
};

const host="http://localhost:8080";
export const EndPoints = {
    SiteKey: '6LfHTFYUAAAAAMj8lHPOFkwLC-HIL-K4MTEVuKzP',
    upload: host + '/api/file/processUpload',
    listAviso: host + '/api/table/courses',
    countAviso: host + '/api/table/count',
    showHtmlAviso: host + '/api/file/showhtml'
};