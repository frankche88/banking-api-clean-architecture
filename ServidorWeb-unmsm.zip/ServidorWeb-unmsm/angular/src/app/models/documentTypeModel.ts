export class DocumentTypeModel {

    constructor(
        public Name: string,
        public Value: string
    ) {}
}
