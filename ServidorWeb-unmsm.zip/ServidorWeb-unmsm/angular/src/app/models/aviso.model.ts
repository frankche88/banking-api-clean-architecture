export interface Aviso {
	filename: string,
	id: number
}
