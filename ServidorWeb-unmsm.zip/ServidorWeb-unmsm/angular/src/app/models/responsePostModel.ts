﻿export class ResponsePostModel {
    public status: string;
    public data: string;
    public message: string;
    public parameters: Array<string>;
}
